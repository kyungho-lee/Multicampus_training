
-----------------------------------------------------
         Generating and Solving 3D Nonograms
                  By Connor Halford
-----------------------------------------------------

To run the program navigate to the 'build' folder and
run the executable file. Your graphics hardware must
support DirectX 11.


*** Controls

WASDQE to move the camera
Arrow keys or hold right mouse to rotate the camera

GUI sections:
Rendering - Toggles for turning on/off various parts.
Model - Choose a model preset or manipulate the
  currently loaded one. Click + Drag to change values
  or Ctrl + Click to type.
Voxels - Change the dimensions of the voxel grid
  prior to puzzle generation.
Puzzle - Generate and solve 3D nonograms. If you load
  a preset the puzzle is automatically generated. The
  solvers can run immediately or animate the process,
  starting will all cells on (Carve) or off (Build).
Log - Output window for various results.


*** Overview

The introduction section of my dissertation gives a
concise overview of what's going on here. In short
the idea is to take a polygonal model, voxelize it to
create a cube approximation, then use that as the
solution for a puzzle and generate the numeric clues
from there. To prove that they are valid, logically
solvable puzzles I also made some 3D puzzle solvers.

The solvers work on one line of the puzzle at a time.
They differ in their approaches to applying the
linesolver algorithm to the puzzle space:

- The brute force solver simply iterates across every
  line of the puzzle and applies the linesolver.
- Whenever the hierarchical solver makes deductions
  it pushes unsolved perpendicular lines into a queue
  which it then processes. This mimics what human
  players do: make deductions, then immediately check
  if the new information can lead to more.
- The heuristic solver assigns a priority to all
  unsolved lines based on a cheap guess of how much
  information the linesolver could get. This also
  mimics a human tactic: look for the easiest line.

My dissertation includes a very in-depth discussion
of how the linesolver algorithm works and how these
different solver approaches compare.